package com.grafkom.viewing3d;

import static org.lwjgl.opengl.GL11.*;

public class ProjectionTaxonomyManager {
    public enum ProjectionType {
        ORTHOGRAPHIC,
        ISOMETRIC,
        OBLIQUE_CAVALIER,
        PERSPECTIVE_1POINT,
        PERSPECTIVE_2POINT,
        PERSPECTIVE_3POINT
    }

    public static void applyProjection(ProjectionType type, float aspect) {
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();

        switch (type) {
            case ORTHOGRAPHIC:
                glOrtho(-3.0 * aspect, 3.0 * aspect, -3.0, 3.0, 0.1, 50.0);
                break;

            case ISOMETRIC:
                glOrtho(-3.0 * aspect, 3.0 * aspect, -3.0, 3.0, 0.1, 50.0);
                glRotatef(35.264f, 1.0f, 0.0f, 0.0f);
                glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
                break;

            case OBLIQUE_CAVALIER:
                // Menggunakan proyeksi ortografik dikombinasikan dengan pergeseran sudut miring
                glOrtho(-3.0 * aspect, 3.0 * aspect, -3.0, 3.0, 0.1, 50.0);
                glMatrixMode(GL_MODELVIEW);
                glLoadIdentity();
                // Memberikan efek miring (shearing/cavalier) pada model view
                glTranslatef(0.0f, 0.0f, -3.0f);
                glRotatef(20.0f, 1.0f, -1.0f, 0.0f);
                break;

            case PERSPECTIVE_1POINT:
                glFrustum(-1.0 * aspect, 1.0 * aspect, -1.0, 1.0, 1.5, 50.0);
                break;

            case PERSPECTIVE_2POINT:
                glFrustum(-0.8 * aspect, 1.2 * aspect, -1.0, 1.0, 1.5, 50.0);
                break;

            case PERSPECTIVE_3POINT:
                glFrustum(-1.0 * aspect, 1.0 * aspect, -1.2, 0.8, 1.5, 50.0);
                glRotatef(10.0f, 1.0f, 0.0f, 0.0f);
                break;
        }
    }
}