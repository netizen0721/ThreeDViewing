package com.grafkom.viewing3d;

import static org.lwjgl.opengl.GL11.*;

public class StereoAnaglyphRenderer {
    private float ipd = 0.15f; // Interpupillary Distance

    public void renderAnaglyph(Runnable renderSceneCallback, Camera3D camera) {
        // PASS 1: Mata Kiri (Saluran Warna Merah / Red Channel)
        glColorMask(true, false, false, true);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glTranslatef(ipd / 2.0f, 0, 0); // Pergeseran kamera mata kiri
        renderSceneCallback.run();
        glPopMatrix();

        // PASS 2: Mata Kanan (Saluran Warna Hijau & Biru / Cyan Channel)
        glColorMask(false, true, true, true);
        glClear(GL_DEPTH_BUFFER_BIT); // Hanya bersihkan depth buffer agar warna ter-blend

        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glTranslatef(-ipd / 2.0f, 0, 0); // Pergeseran kamera mata kanan
        renderSceneCallback.run();
        glPopMatrix();

        // Reset Color Mask ke normal (RGB Aktif)
        glColorMask(true, true, true, true);
    }

    public float getIpd() { return ipd; }
    public void setIpd(float ipd) { this.ipd = ipd; }
}