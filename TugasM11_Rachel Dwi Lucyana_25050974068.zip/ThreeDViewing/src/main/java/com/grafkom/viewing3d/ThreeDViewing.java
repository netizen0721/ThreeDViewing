package com.grafkom.viewing3d;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.glfw.*;
import org.lwjgl.opengl.*;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.system.MemoryUtil.NULL;

public class ThreeDViewing {
    private long window;
    private int width = 1024;
    private int height = 768;

    private Camera3D camera;
    private PerspectiveProjection projection;
    private StereoAnaglyphRenderer stereoRenderer;

    private ProjectionTaxonomyManager.ProjectionType currentMode =
            ProjectionTaxonomyManager.ProjectionType.PERSPECTIVE_1POINT;

    private boolean enableStereo = false;

    // Kontrol Orbital Kamera
    private float cameraRadius = 6.0f;
    private float azimuth = 45.0f;
    private float elevation = 30.0f;

    // Input Mouse
    private double lastMouseX, lastMouseY;
    private boolean isMousePressed = false;

    public void run() {
        init();
        loop();

        glfwDestroyWindow(window);
        glfwTerminate();
    }

    private void init() {
        if (!glfwInit()) {
            throw new IllegalStateException("Gagal menginisialisasi GLFW");
        }

        window = glfwCreateWindow(width, height, "3D Viewing Interactive Visualizer", NULL, NULL);
        if (window == NULL) {
            throw new RuntimeException("Gagal membuat jendela GLFW");
        }

        // Setup Callback Mouse Drag untuk Orbital Camera
        glfwSetMouseButtonCallback(window, (win, button, action, mods) -> {
            if (button == GLFW_MOUSE_BUTTON_LEFT) {
                isMousePressed = (action == GLFW_PRESS);
            }
        });

        glfwSetCursorPosCallback(window, (win, xpos, ypos) -> {
            if (isMousePressed) {
                float dx = (float) (xpos - lastMouseX);
                float dy = (float) (ypos - lastMouseY);
                azimuth += dx * 0.5f;
                elevation += dy * 0.5f;

                // Batasi sudut elevasi agar kamera tidak terbalik
                elevation = Math.max(-89.0f, Math.min(89.0f, elevation));
            }
            lastMouseX = xpos;
            lastMouseY = ypos;
        });

        // Setup Callback Keyboard untuk Navigasi & Pilihan Mode Proyeksi
        glfwSetKeyCallback(window, (win, key, scancode, action, mods) -> {
            if (action == GLFW_PRESS) {
                switch (key) {
                    case GLFW_KEY_1 -> currentMode = ProjectionTaxonomyManager.ProjectionType.ORTHOGRAPHIC;
                    case GLFW_KEY_2 -> currentMode = ProjectionTaxonomyManager.ProjectionType.ISOMETRIC;
                    case GLFW_KEY_3 -> currentMode = ProjectionTaxonomyManager.ProjectionType.OBLIQUE_CAVALIER;
                    case GLFW_KEY_4 -> currentMode = ProjectionTaxonomyManager.ProjectionType.PERSPECTIVE_1POINT;
                    case GLFW_KEY_5 -> currentMode = ProjectionTaxonomyManager.ProjectionType.PERSPECTIVE_2POINT;
                    case GLFW_KEY_6 -> currentMode = ProjectionTaxonomyManager.ProjectionType.PERSPECTIVE_3POINT;
                    case GLFW_KEY_S -> enableStereo = !enableStereo; // Toggle Stereo Anaglyph Mode
                    case GLFW_KEY_UP -> cameraRadius = Math.max(2.0f, cameraRadius - 0.5f);   // Zoom In
                    case GLFW_KEY_DOWN -> cameraRadius += 0.5f;                                // Zoom Out
                }
            }
        });

        glfwMakeContextCurrent(window);
        glfwSwapInterval(1);
        GL.createCapabilities();

        glEnable(GL_DEPTH_TEST);

        // Inisialisasi Komponen OOP
        camera = new Camera3D(
                new Vector3f(0, 0, cameraRadius),
                new Vector3f(0, 0, 0),
                new Vector3f(0, 1, 0)
        );
        projection = new PerspectiveProjection(45.0f, (float) width / height, 0.1f, 50.0f);
        stereoRenderer = new StereoAnaglyphRenderer();
    }

    private void loop() {
        while (!glfwWindowShouldClose(window)) {
            glClearColor(0.1f, 0.1f, 0.15f, 1.0f);

            // Update posisi kamera orbital
            camera.updateOrbitalPosition(cameraRadius, azimuth, elevation);

            float aspect = (float) width / height;

            if (enableStereo) {
                ProjectionTaxonomyManager.applyProjection(ProjectionTaxonomyManager.ProjectionType.PERSPECTIVE_1POINT, aspect);
                stereoRenderer.renderAnaglyph(this::renderScene, camera);
            } else {
                glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
                ProjectionTaxonomyManager.applyProjection(currentMode, aspect);

                glMatrixMode(GL_MODELVIEW);
                glLoadIdentity();

                // Terapkan LookAt View Matrix
                Matrix4f viewMatrix = camera.calculateLookAtMatrix();
                float[] buffer = new float[16];
                viewMatrix.get(buffer);
                glLoadMatrixf(buffer);

                renderScene();
            }

            glfwSwapBuffers(window);
            glfwPollEvents();
        }
    }

    private void renderScene() {
        Mesh3D.drawColorCube();
    }

    public static void main(String[] args) {
        new ThreeDViewing().run();
    }
}